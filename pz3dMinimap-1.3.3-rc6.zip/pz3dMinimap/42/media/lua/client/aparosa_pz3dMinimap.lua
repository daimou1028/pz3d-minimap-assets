-- 円形で、人物の向きに合わせて回る小地図（試作。重さを測るための物）
-- 原版の地図（UIWorldMap）は Lua から回せないので、周りのマスを読んで自前で描く（docs/vanilla-reference-ja.md）。
-- 描き方: 世界の 1 行ごとに同じ色のマスをまとめ、回した四角形 1 つとして 4 隅指定で描く。円は setStencilCircle で切る。
-- client に置く理由: ISUIElement が client の file。require は原版の PZAPI/ModOptions だけ（設定の頁の API）。

-- 設定の頁（ゲームの設定 → Mods）の API。PZ3D 0.4 の PZ3DOptions.lua と同じく require で読込順を決める
require "PZAPI/ModOptions"

aparosa_pz3dMinimap = aparosa_pz3dMinimap or {}
local M = aparosa_pz3dMinimap

M.config = {
    enabled = true,
    radius = 40,     -- 描くマスの半径。読み込まれている範囲は約 52 マス（13 チャンク x 8 / 2）
    -- 画面上の直径。基準の高さ 830px の時に 240px で、画面の高さに比例して大きくする（利用者の指定 2026-09-29。
    -- 830 は利用者が位置を決めた時の画面 1470x830）
    baseSize = 240,
    baseScreenH = 830,
    -- 利用者が横桿で変える倍率の幅（利用者の指定 2026-09-29: 大きくし過ぎ・小さくし過ぎを防ぐ）
    userScale = 1.0,
    minUserScale = 0.5,
    maxUserScale = 2.0,
    -- 操作の大きさ（px、基準の 830px の時）。
    -- 大きさの桿は縦にして円の右上に置く（利用者の指定 2026-09-29「改成垂直拉桿，放在右上角，大小變更起點是右上角」）
    scaleStep = 0.1, -- 大きさの ▲▼ 釦 1 回の変わる量（倍率）
    borderPx = 3,    -- 円の黒い縁の太さ（基準の 830px の時。画面の高さに比例）
    margin = 22,     -- 速度ボタン（無ければ時計）の下・気分の絵の左との間（px）。利用者が置いた位置から測った値
    refreshRows = 4, -- 1 フレームに色を読み直す行の数
    -- 滾輪の拡大・縮小の幅（利用者の決定 2026-09-29: 5〜55）。最大は読み込まれている範囲に収める。
    -- 単機で撮って、半径 60 で縁が黒くなり始め、70 で四隅が黒かった（読み込みは人物の周り約 ±60 の正方形）。
    -- 重さは Lua で半径 50 が 13ms、60 が 18ms/フレーム（Mac、-debug、2026-09-29）
    minRadius = 5,
    -- 最大は読み込まれている所（人物の周り約 ±58）に収め、縁に読まれていない黒い所が出ないようにする
    -- （利用者「範圍加到最大會出現一點點黑匡」2026-09-29。55 では斜めの時と、人物がチャンクの端に居る時に縁が黒くなった）。
    -- 斜めは縦に √2 倍遠くまで要るので 40（40 x 1.414 = 57）
    maxRadius = 50,
    maxRadiusIso = 40,
    zoomStep = 1.2,  -- 1 刻みの倍率
    -- 地図の見た目（材質）。円の右下の釦で順に替える（利用者の指定 2026-09-29「地圖材質切換」「預設應該用跟原本地圖相同材質」）
    theme = "vanilla",
    -- 視角（左下の 1 つの釦で順に替える。利用者の決定 2026-09-29: 回し方と斜めの釦を 1 つにまとめる）:
    --   "camera" = PZ3D の鏡頭の向きを上にして回す（既定。利用者「預設改為跟著鏡頭，可以切換為跟著人物」）。
    --              PZ3D は鏡頭の向き（LookState.yaw）を Lua へ出していない（0.3.0 の Main の public は 0.2.2 と同じ）。
    --              ただし一人称では毎フレーム人物の向きを鏡頭の向きに合わせる（NativeLocomotion.face が
    --              setTargetAndCurrentDirection(cos yaw, sin yaw) を呼ぶ。cameraFacing は FIRST_PERSON で常に真）。
    --              三人称では人物が鏡頭に合わせて回らない（狙う時だけ）。利用者の試し（Windows、2026-09-29）で
    --              人物の向きでは鏡頭に付いて来なかったので、PZ3D・Project Viewpoint の鏡頭の向きを同梱の Java で直に読む（M.cameraYaw）。どちらも無い時は auto と同じ
    --   "auto"  = 真上から、人物の向き（体の回る角度 getAnimAngleRadians、滑らか）を上にして回す
    --   "north" = 真上から、北を上に止め、人物の印だけ回す（「視角固定或自動的切換」）
    --   "iso"   = 原版の地図の Isometric と同じ斜め（45 度回して縦を半分に潰す。WorldMapRenderer.java 197 行）。
    --             向きは遊戲の画面と同じ（北が右上）に止め、人物の印が向きを指す（「跟原版一樣的斜45度角」）
    view = "camera",
    -- 殭屍の点: "visible" = 人物に見えている殭屍だけ / "all" = 範囲の全部 / "off"。既定は visible（利用者の決定 2026-09-29）。
    -- 見えているかは、ゲームが殭屍を描くかを決める同じマスの見え方（IsoGridSquare.isCanSee、9219 行）で判じる
    zombies = "visible",
    -- マウスが小地図から離れた後、操作を残す時間（ms）。値の根拠は無い。円から桿へ移る間に消えない程度として置いた
    controlsLingerMs = 1000,
}

-- 回る速さの滑らかさ（ゲームの設定 → Mods の頁の横桿、0〜10。0 = すぐ追いつく、今までと同じ）。
-- 利用者の要望（2026-09-30「地圖旋轉靈敏度」→ 平滑度を選んだ）: マウスの細かい揺れで地図が震えないようにする。
-- 1 段 = 追いつく時定数 0.04 秒（10 で 0.4 秒）。値の根拠は無い。遅れが目に見えて気になり始める所を上限にした目安
local SMOOTH_TAU_PER_STEP = 0.04
-- ゲームの設定 → Mods の頁（原版 client/PZAPI/ModOptions.lua）。作るのは file の最後（M.createOptions。見た目・視角の順の表の後）。
-- 利用者の要望（2026-09-30「如果還有其他可以讓玩家設定的也可以盡可能讓玩家設定」）で、釦・桿・滾輪で変えられる物も全部ここに置き、
-- ゲームの中で変えた物もここへ書き戻して保存する（次にゲームを始めた時も同じになる）
local modOptions

function M.smoothing()
    return M.config.smoothing or 0
end

-- 表示する角度を目標の角度へ指数で近づける。差は -pi〜pi に丸めて近い方へ回る。0 段なら目標そのまま
function M.smoothAngle(panel, target)
    local level = M.smoothing()
    local now = getTimestampMs()
    local last = panel.smoothT or now
    panel.smoothT = now
    if level <= 0 or panel.smoothA == nil then
        panel.smoothA = target
        return target
    end
    local d = target - panel.smoothA
    d = d - 2 * math.pi * math.floor((d + math.pi) / (2 * math.pi))
    local dt = math.min(0.25, (now - last) / 1000)
    local k = 1 - math.exp(-dt / (level * SMOOTH_TAU_PER_STEP))
    panel.smoothA = panel.smoothA + d * k
    return panel.smoothA
end

local ZOMBIE_ORDER = { "visible", "all", "off" }
local VIEW_ORDER = { "camera", "auto", "north", "iso" }

-- 3D の mod の鏡頭の向き（世界の角度、ラジアン）。PZ3D か Project Viewpoint の 3D でない時は nil。
-- 同梱の Java（java/src/aparosa/pz3dminimap/CameraLink.java）が ZombieBuddy の LuaClass で Lua へ Pz3dMinimapCamera を出し、
-- PZ3D の内部の LookState.get().yaw()、Viewpoint の Look.yaw を反射で読む。ZombieBuddy が無ければ Pz3dMinimapCamera は無く、人物の向きを使う。
-- 前の試作（マウスの横の動きを数える）は、PZ3D がマウスを掴む間 getMouseX が -10000 を返して使えなかった（2026-09-29、利用者の console）
function M.cameraYaw(player)
    local mode = PZ3D and PZ3D.cameraMode and PZ3D.cameraMode() or 0
    if mode == 0 then
        -- Project Viewpoint: 3D の間だけ数が返る（車の中でも世界の角度）。無い・3D でない時は NaN
        local vp = Pz3dMinimapCamera and Pz3dMinimapCamera.viewpointYaw and Pz3dMinimapCamera.viewpointYaw()
        if vp ~= nil and vp == vp then return vp end
        return nil
    end
    local yaw = Pz3dMinimapCamera and Pz3dMinimapCamera.yaw and Pz3dMinimapCamera.yaw()
    if yaw ~= nil and yaw ~= yaw then yaw = nil end  -- NaN（読めなかった）
    -- 読めない時: 一人称と狙う時は人物の向き = 鏡頭の向き（NativeLocomotion.face）、三人称は人物の向き
    local face = player:getDirectionAngleRadians()
    -- 車の中では PZ3D の yaw は車体から見た首の角度（0 = 車の正面、±110° まで。VehicleLook.HEAD_LIMIT、
    -- VehicleMotion の view が chassis の回転を掛けてから (-sin yaw, ·, cos yaw) を向く）。世界の角度ではないので、
    -- 車の向きを足す。乗っている間の人物の向きは車に付いて回る（Windows の実測 2026-09-30: 首を回しても dir は動かず、
    -- 車の getAngleY と dir ≈ angleY - 90° の関係）。足す向きの符号は chassis の軸の入れ替えから +（Windows で要確認）
    local seated = (PZ3D.inVehicle and PZ3D.inVehicle()) or player:getVehicle() ~= nil
    if seated then return face + (yaw or 0) end
    return yaw or face
end

-- 見た目の順（釦を押すと次へ）
local THEME_ORDER = { "vanilla", "flat" }

local function rgb(r, g, b) return { r / 255, g / 255, b / 255 } end

-- 見た目ごとの色（r, g, b）。bg = 円の地の色。色の無い種類は描かず地の色のまま見せる
local THEMES = {}
-- 原版の地図と同じ色（client/ISUI/Maps/ISMapDefinitions.lua の initDefaultStyleV1、163〜316 行、42.21.0）:
-- 紙の地 219,215,192 / 森 189,197,163 / 水 59,141,149 / 主な道 134,125,113 / 小道 171,158,143 / 建物（住宅）210,158,105。
-- 原版は草地・土を塗らず紙の地のまま見せ、壁は描かない。ここでは壁だけ建物の色を暗くして描く（部屋の形が分かるように）
THEMES.vanilla = {
    bg = rgb(219, 215, 192),
    none = rgb(200, 197, 176),  -- 読み込まれていない所。原版の未訪問（地 x 0.915）に近い色
    water = rgb(59, 141, 149),
    wall = rgb(140, 100, 62),
    room = rgb(210, 158, 105),
    tree = rgb(189, 197, 163),
    road = rgb(134, 125, 113),
    floor = rgb(171, 158, 143),
    paper = true,               -- 原版と同じく紙の絵を薄く重ねる（MapUtils.overlayPaper、352〜375 行: 白 alpha 32 + Paper.png）
}
-- 試作から使っていた色
THEMES.flat = {
    -- 地の色 = 読み込まれていない所に見える色（「none」は描かないので地が見える）。黒だと縁が黒い枠に見えたので灰にした
    bg       = { 0.22, 0.22, 0.22 },
    none     = { 0.22, 0.22, 0.22 },
    water    = { 0.20, 0.40, 0.75 },
    wall     = { 0.15, 0.15, 0.15 },
    room     = { 0.55, 0.50, 0.45 },
    tree     = { 0.18, 0.40, 0.18 },
    road     = { 0.35, 0.35, 0.37 },
    grass    = { 0.32, 0.52, 0.28 },
    ground   = { 0.50, 0.45, 0.33 },
    floor    = { 0.60, 0.58, 0.55 },
}
local PAPER_TEX = getTexture("media/textures/worldMap/Paper.png")

-- 色の記録: cache[y][x] = 種類の名前。z は人物の階だけ
local cache = {}
-- 行ごとの同じ色の続き（runs[y] = { x1, x2, 始め, 終わり+1, 種類, ... }）。行の中身か x1・x2 が変わった時だけ作り直す。
-- 毎フレーム範囲の全マス（半径 40 で約 6500）を見て続きを探していたのをやめた（2026-09-29、重さを減らすため）
local runs = {}
local cacheZ = nil

-- 読んだマスを全部捨てる（看過の所だけの設定を切り替えた時。次のフレームから読み直す）
function M.clearCache()
    cacheZ = nil
end
local refreshY = nil
local stats = { frames = 0, quads = 0, luaMs = 0, maxMs = 0, since = 0 }
local materials = {}

local function classify(sq)
    if not sq then return "none" end
    -- 見た事のある所だけ（設定の頁、既定は切）。原版がマスを暗くするかを決める印 IsoGridSquare.isSeen（9409 行、明かりの計算が立てる）
    if M.config.seenOnly and not sq:isSeen(0) then return "none" end
    if sq:isWaterSquare() then return "water" end
    if sq:getWall(true) or sq:getWall(false) then return "wall" end
    if sq:getRoom() then return "room" end
    if sq:getTree() then return "tree" end
    local floor = sq:getFloor()
    if not floor then return "none" end
    local mat = floor:getProperties() and floor:getProperties():get("FloorMaterial")
    local name = floor:getSprite() and floor:getSprite():getName() or ""
    local key = tostring(mat) .. " " .. (string.match(name, "^(.-)_%d+$") or name)
    materials[key] = (materials[key] or 0) + 1
    if string.find(name, "street", 1, true) then return "road" end
    if mat == "Grass" then return "grass" end
    if mat == "Gravel" or mat == "Sand" or mat == "Dirt" then return "ground" end
    if string.find(name, "blends_natural", 1, true) then return "grass" end
    return "floor"
end

-- 行の x1〜x2 を読む。all が偽なら、まだ読んでいないマスだけを読む。
-- 前は行の端が欠けると行ごと読み直しており、人物が 1 マス動くと範囲の全マス（半径 40 で約 6500）を 1 フレームで読んで
-- 止まった（2026-09-29、利用者「好卡頓」。行の端 x1・x2 は動くたびに変わるため、すべての行が欠けて見えた）
local function readRow(cell, y, x1, x2, z, all)
    local row = cache[y]
    if not row then row = {}; cache[y] = row end
    for x = x1, x2 do
        if all or row[x] == nil then
            local kind = classify(cell:getGridSquare(x, y, z))
            if row[x] ~= kind then
                row[x] = kind
                runs[y] = nil
            end
        end
    end
end

-- 人物が前に掃除した所から半径より遠くへ動いたら、範囲の外のマスを捨てる（記録が際限なく増えないように）
local pruneX, pruneY = nil, nil
local function prune(px, py, r)
    if pruneX and math.abs(px - pruneX) <= r and math.abs(py - pruneY) <= r then return end
    pruneX, pruneY = px, py
    local keep = {}
    for y = py - r * 2, py + r * 2 do
        local row = cache[y]
        if row then
            local nrow = {}
            for x = px - r * 2, px + r * 2 do nrow[x] = row[x] end
            keep[y] = nrow
        end
    end
    cache = keep
    runs = {}
end

local CIRCLE_TEX = getTexture("media/ui/circle.png")
-- 縁の環・釦・桿の絵（tools/make-ui-textures.py が作る。RING_OUT は同じ script の RING_OUT と同じ値）
local UI_DIR = "media/ui/pz3dMinimap/"
local RING_TEX = getTexture(UI_DIR .. "ring.png")
local RING_OUT = 0.02
local RING_IN = 0.02
local STENCIL_INSET = 0.012
local BUTTON_TEX = getTexture(UI_DIR .. "button.png")
local ICON_TEX = {
    camera = getTexture(UI_DIR .. "icon-camera.png"),
    auto = getTexture(UI_DIR .. "icon-rotate.png"),
    north = getTexture(UI_DIR .. "icon-north.png"),
    iso = getTexture(UI_DIR .. "icon-iso.png"),
    visible = getTexture(UI_DIR .. "icon-zombies-visible.png"),
    all = getTexture(UI_DIR .. "icon-zombies-all.png"),
    off = getTexture(UI_DIR .. "icon-zombies-off.png"),
    up = getTexture(UI_DIR .. "icon-up.png"),
    down = getTexture(UI_DIR .. "icon-down.png"),
}

M.Panel = ISUIElement:derive("aparosa_pz3dMinimapPanel")

function M.Panel:render()
    local cfg = M.config
    if not cfg.enabled then return end
    local player = getSpecificPlayer(0)
    if not player then return end
    local t0 = getTimestampMs()
    local cell = getCell()
    local px, py = player:getX(), player:getY()
    local pz = math.floor(player:getZ())
    local r = math.min(cfg.radius, cfg.view == "iso" and cfg.maxRadiusIso or cfg.maxRadius)
    -- 斜めの時は縦を半分に潰すので、同じ円を埋めるには縦に遠くまで要る。表示を √2 倍に寄せ、読む範囲を √2 倍に広げる
    -- （読む範囲は読み込まれている所に収める）
    local iso = cfg.view == "iso"
    local isoK = iso and 1.4142 or 1
    local rr0 = iso and math.min(math.ceil(r * 1.4142), 58) or r
    local x1, x2 = math.floor(px) - rr0, math.floor(px) + rr0
    local y1, y2 = math.floor(py) - rr0, math.floor(py) + rr0
    if cacheZ ~= pz then cache = {}; runs = {}; cacheZ = pz end

    -- 無い行は読み、残りは数行ずつ順に読み直す（壁を建てた等の変化を拾う）
    prune(math.floor(px), math.floor(py), r)
    local theme = THEMES[cfg.theme] or THEMES.vanilla
    for y = y1, y2 do
        local row = cache[y]
        if not row or row[x1] == nil or row[x2] == nil then
            readRow(cell, y, x1, x2, pz, false)
        end
    end
    if not refreshY or refreshY < y1 or refreshY > y2 then refreshY = y1 end
    for _ = 1, cfg.refreshRows do
        readRow(cell, refreshY, x1, x2, pz, true)
        refreshY = refreshY + 1
        if refreshY > y2 then refreshY = y1 end
    end

    -- 向き: 人物が向いている方向を画面の上にする。θ = -pi/2 - 向き
    -- camera の時は、PZ3D の 3D の間は鏡頭の向きを数える（M.cameraYaw）。それ以外は体の角度（滑らか）
    local camYaw = cfg.view == "camera" and M.cameraYaw(player) or nil
    local a = M.smoothAngle(self, camYaw or player:getAnimAngleRadians())
    -- 北を上に止める時は回さない（th = 0）。
    -- 斜めの時は原版の地図の Isometric と同じく、先に 45 度回してから縦を潰す（rotateXYZ(60°, 0, 45°)、WorldMapRenderer.java 197 行）。
    -- 回さずに潰すだけだと、マスが横長の四角になり比例がおかしかった（利用者「比例很怪」2026-09-29）。
    -- 45 度回すとマスが幅:高さ 2:1 の菱形になり、ゲームの画面と同じ向き（世界の x+ が右下、y+ が左下）になる。
    -- 画面に合わせるため、斜めの時は人物の向きでは回さず、人物の印の三角が向きを指す
    local th
    if iso then
        th = math.pi / 4
    elseif cfg.view == "north" then
        th = 0
    else
        th = -math.pi / 2 - a
    end
    local c, s = math.cos(th), math.sin(th)
    local w = self.mapSize or self:getWidth()  -- 円の直径。要素はこれに右の桿の列と下の釦の行を足した大きさ
    local cx, cy = w / 2, w / 2
    local k = w / (2 * r) * isoK
    -- 4 隅指定の DrawTexture は自分の位置を足さない（UIElement.java 304〜317 行）ので、画面の絶対座標で渡す
    local ax, ay = self:getAbsoluteX() + cx, self:getAbsoluteY() + cy
    local kc, ks = k * c, k * s
    -- 画面の縦の成分だけに掛ける倍率（斜めの時 0.5 = cos 60 度）
    local sqz = iso and 0.5 or 1
    local kcY, ksY = kc * sqz, ks * sqz

    -- 黒い縁は地図を描いた後に環の絵（RING_TEX）で重ねる。環の絵が無い時だけ、前の形（原版の circle.png を黒で塗って
    -- 地図の後ろに大きく描く）にする
    if not RING_TEX and CIRCLE_TEX then
        local border = math.max(2, math.floor(cfg.borderPx * getCore():getScreenHeight() / cfg.baseScreenH + 0.5))
        self:drawTextureScaled(CIRCLE_TEX, -border, -border, w + border * 2, w + border * 2, 1, 0, 0, 0)
    end
    -- 型（原版 circle.png 88x88 を拡大した物）の縁は、標準の円より外へ 0〜2.1% 出る（Windows の 1.3.2 の特写 edge-now-scale1/2 で
    -- 縁の黒から地図の地へ変わる所を 1,448・2,108 点測った。内へは入らない）。型を直径の STENCIL_INSET だけ内へ縮め、
    -- 段の出る帯（内 1.2%〜外 0.9%）を縁の環（内 RING_IN・外 RING_OUT）の中に収める
    if RING_TEX then
        local e = STENCIL_INSET * w
        self:setStencilCircle(e, e, w - e * 2, w - e * 2)
    else
        self:setStencilCircle(0, 0, w, w)
    end
    local bg = theme.bg
    local alpha = cfg.opacity or 1   -- 地図の不透明度（設定の頁、30〜100%）
    self:drawRect(0, 0, w, w, alpha, bg[1], bg[2], bg[3])
    local jo = self.javaObject
    local quads = 0
    for y = y1, y2 do
        local rr = runs[y]
        if not rr or rr[1] ~= x1 or rr[2] ~= x2 then
            -- この行の同じ色の続きを作り直す（「none」は描かないので入れない）
            local row = cache[y]
            rr = { x1, x2 }
            local runStart, runKind = x1, row[x1]
            for x = x1 + 1, x2 + 1 do
                local kind = row[x]
                if x > x2 or kind ~= runKind then
                    if runKind ~= "none" then
                        rr[#rr + 1] = runStart
                        rr[#rr + 1] = x
                        rr[#rr + 1] = runKind
                    end
                    runStart, runKind = x, kind
                end
            end
            runs[y] = rr
        end
        -- 回した四角の 4 隅: 画面 = a + k * 回転(dx, dy)。関数を呼ばずに式を書き下す
        local dy0, dy1 = y - py, y + 1 - py
        local ay0x, ay0y, ay1x, ay1y = ax - dy0 * ks, ay + dy0 * kcY, ax - dy1 * ks, ay + dy1 * kcY
        for i = 3, #rr, 3 do
            local dx0, dx1 = rr[i] - px, rr[i + 1] - px
            local col = theme[rr[i + 2]]
            if col then
                local x0c, x0s, x1c, x1s = dx0 * kc, dx0 * ksY, dx1 * kc, dx1 * ksY
                jo:DrawTexture(nil,
                    ay0x + x0c, ay0y + x0s, ay0x + x1c, ay0y + x1s,
                    ay1x + x1c, ay1y + x1s, ay1x + x0c, ay1y + x0s,
                    col[1], col[2], col[3], alpha)
                quads = quads + 1
            end
        end
    end
    if theme.paper and PAPER_TEX then
        -- 原版と同じく、紙の絵を白 alpha 32/255 で重ねる（ISMapDefinitions.lua 368〜372 行）
        self:drawTextureScaled(PAPER_TEX, 0, 0, w, w, 32 / 255 * alpha, 1, 1, 1)
    end
    -- 殭屍の点（円の中だけ。型で切っている間に描く）
    if cfg.zombies ~= "off" then
        quads = quads + self:drawZombies(player, px, py, pz, rr0, ax, ay, kc, ks, kcY, ksY, k)
    end
    -- 人物の印: 向いている方向を指す三角（北を上に止めた時も向きが分かるように、画面の上の向きへ回して描く）
    local fa = a + th                     -- 画面の上での向き（auto の時は常に -pi/2 = 上）
    local fx, fy = math.cos(fa), math.sin(fa) * sqz
    local fl = math.sqrt(fx * fx + fy * fy); fx, fy = fx / fl, fy / fl
    local sz = math.max(6, w / 30)
    local tipX, tipY = ax + fx * sz, ay + fy * sz
    local backX, backY = ax - fx * sz * 0.4, ay - fy * sz * 0.4
    local sideX, sideY = -fy * sz * 0.6, fx * sz * 0.6
    jo:DrawTexture(nil, tipX, tipY, backX + sideX - fx * sz * 0.3, backY + sideY - fy * sz * 0.3, backX, backY,
        backX - sideX - fx * sz * 0.3, backY - sideY - fy * sz * 0.3, 1, 0.2, 0.2, 1)
    self:clearStencilRect()
    self:repaintStencilRect(0, 0, w, w)
    -- 黒い縁の環: 反鋸歯の絵を円の縁に重ね、原版の型（88x88 の circle.png を拡大した物）の段と、上下左右の平らな所を隠す
    -- （利用者 2026-09-30「圓形上下左右都有點不夠圓、鋸齒有點嚴重」。1 枚描くだけで重さは変わらない。tools/make-ui-textures.py）
    if RING_TEX then
        local ro = RING_OUT * w
        self:drawTextureScaled(RING_TEX, -ro, -ro, w + ro * 2, w + ro * 2, 1, 1, 1, 1)
    end
    -- 操作（桿と釦）はマウスが小地図の上に在る間だけ出し、離れてから少しの間（controlsLingerMs）残す。
    -- 普段は円だけにする（工坊の利用者の要望 2026-09-30「怎麼把小地圖周圍的圖示全部隱藏，讓介面保持乾淨」）。
    -- 残すのは、円から右上の桿へマウスを移す途中で隙間を通っても消えないようにするため。
    -- PZ3D がマウスを掴む間は getMouseX が -10000 を返すので、3D の間は常に隠れる
    local now = getTimestampMs()
    if cfg.alwaysControls or self:isMouseOver() or self.moving then self.controlsUntil = now + M.config.controlsLingerMs end
    M.saveIfDue()
    if now < (self.controlsUntil or 0) then
        self:drawControls(w)
    end
    if M.toastText and getTimestampMs() < (M.toastUntil or 0) then
        local font = UIFont.Small
        local tw = getTextManager():MeasureStringX(font, M.toastText)
        local fh = getTextManager():getFontHeight(font)
        local tx, ty = w / 2, w * 0.12
        self:drawRect(tx - tw / 2 - 6, ty - 2, tw + 12, fh + 4, 0.7, 0, 0, 0)
        self:drawTextCentre(M.toastText, tx, ty, 1, 1, 1, 1, font)
    end

    stats.frames = stats.frames + 1
    stats.quads = stats.quads + quads
    local ms = getTimestampMs() - t0
    stats.luaMs = stats.luaMs + ms
    if ms > stats.maxMs then stats.maxMs = ms end
end

-- 殭屍を点で描く。範囲（読む半径 r）の中で、同じ階の物だけ
function M.Panel:drawZombies(player, px, py, pz, r, ax, ay, kc, ks, kcY, ksY, k)
    local list = getCell():getZombieList()
    if not list then return 0 end
    local jo = self.javaObject
    local onlyVisible = M.config.zombies == "visible"
    local r2 = r * r
    local dot = math.max(2, math.min(6, k * 0.9))
    local n = 0
    for i = 0, list:size() - 1 do
        local z = list:get(i)
        if z and not z:isDead() and math.floor(z:getZ()) == pz then
            local dx, dy = z:getX() - px, z:getY() - py
            if dx * dx + dy * dy <= r2 then
                local sq = z:getCurrentSquare()
                if not onlyVisible or (sq and sq:isCanSee(player:getPlayerNum())) then
                    local x = ax + dx * kc - dy * ks
                    local y = ay + dx * ksY + dy * kcY
                    jo:DrawTexture(nil, x - dot, y - dot, x + dot, y - dot, x + dot, y + dot, x - dot, y + dot,
                        0.85, 0.1, 0.1, 1)
                    n = n + 1
                end
            end
        end
    end
    return n
end

-- 操作の大きさの倍率。円と同じく画面の高さに比例させる（4K で小さくなり過ぎないように）
local function uiScale()
    return getCore():getScreenHeight() / M.config.baseScreenH
end

-- 円の下の操作: 大きさの横桿は円の真下の中央に、切替の釦は右に寄せる（利用者の指定 2026-09-29「橫桿改到圓形正下方」「右側區域放各種切換按鈕」）。
-- 右から 斜めの釦・見た目の釦。幅・高さ・つまみは uiScale 倍
-- 釦の一辺: 原版の速さの釦と同じ（利用者 2026-09-30「三角形按鈕跟那三個按鈕應該跟上面的時鐘調速按鈕一樣大吧」）。
-- 速さの釦は 22px の絵に縁 6px を足した物（SpeedControls.java 235〜241 行 SCButton、絵 media/ui/speedControls/*_Off.png は高さ 22）で、
-- 画面の大きさでは変わらない。速さの釦が出ている時はその高さ、出ていない時（多人など）は同じ 28
local function buttonSize()
    local speed = UIManager.getSpeedControls()
    if speed and speed:isVisible() and speed:getHeight() > 0 then return speed:getHeight() end
    return 28
end

local function controlRects(w)
    -- 操作は円の右の 1 列に、上から ▲（大きく）▼（小さく）視角・殭屍・見た目を続けて並べる。
    -- ▲ の上端を金属の縁の外側（円の見た目の上端）に揃える。釦の間は原版の速さの釦と同じ 2px。
    -- 利用者（2026-09-30）: 「垂直排在拉桿的下方」→「改成向上向下的三角形來分段變更大小」→「三個按鈕不用跟著圓圈下緣跑，直接接著三角形」
    local col, gap = buttonSize(), 2
    local edge = RING_TEX and RING_OUT * w or 0
    local bx = w + edge + 4
    local upY = -edge
    local downY = upY + col + gap
    local rotY = downY + col + gap
    local zombY = rotY + col + gap
    local themeY = zombY + col + gap
    return { bx = bx, bw = col, h = col, gap = gap, upY = upY, downY = downY, rotY = rotY, zombY = zombY, themeY = themeY }
end

-- 切り替えた時に、今の状態を円の上に少しの間（1.5 秒）字で出す。字は翻訳の表（IGUI_pz3dMinimap_<鍵>）から引く
function M.toastRaw(text)
    if M.config.toast == false then return end
    M.toastText = text
    M.toastUntil = getTimestampMs() + 1500
end

function M.toast(key)
    if M.config.toast == false then return end
    M.toastText = getText("IGUI_pz3dMinimap_" .. key)
    M.toastUntil = getTimestampMs() + 1500
end

-- 視角を次へ替える（俯瞰・回る → 俯瞰・北が上 → 斜め）
function M.nextView()
    local cfg = M.config
    for i, name in ipairs(VIEW_ORDER) do
        if name == cfg.view then
            cfg.view = VIEW_ORDER[i % #VIEW_ORDER + 1]
            return
        end
    end
    cfg.view = VIEW_ORDER[1]
end

-- 殭屍の点の出し方を次へ替える
function M.nextZombies()
    local cfg = M.config
    for i, name in ipairs(ZOMBIE_ORDER) do
        if name == cfg.zombies then
            cfg.zombies = ZOMBIE_ORDER[i % #ZOMBIE_ORDER + 1]
            break
        end
    end
end

-- 見た目を次へ替える
function M.nextTheme()
    local cfg = M.config
    for i, name in ipairs(THEME_ORDER) do
        if name == cfg.theme then
            cfg.theme = THEME_ORDER[i % #THEME_ORDER + 1]
            break
        end
    end
end

-- 絵を使う操作（利用者 2026-09-30「按鈕可以再精緻一點嗎？右邊的拉桿也是，感覺好簡陋」）。
-- 釦は暗い半透明の角丸（button.png）に白い印、見た目の釦だけは今の配色の見本を角丸の中に描く。桿は角丸の溝と丸いつまみ。
-- 押せる範囲（controlRects）は前と同じ
function M.Panel:drawControlsTex(w)
    local cfg = M.config
    local r = controlRects(w)
    -- 釦の下地と印（印は釦の 80%）。金属の縁と暗いガラスの面（tools/make-ui-textures.py）
    local pad = r.bw * 0.1
    local function button(y, icon)
        self:drawTextureScaled(BUTTON_TEX, r.bx, y, r.bw, r.h, 1, 1, 1, 1)
        if icon then
            local s = math.min(r.bw, r.h) - pad * 2
            self:drawTextureScaled(icon, r.bx + (r.bw - s) / 2, y + (r.h - s) / 2, s, s, 1, 1, 1, 1)
        end
    end
    button(r.upY, ICON_TEX.up)
    button(r.downY, ICON_TEX.down)
    button(r.rotY, ICON_TEX[cfg.view])
    button(r.zombY, ICON_TEX[cfg.zombies])
    button(r.themeY, nil)
    local theme = THEMES[cfg.theme] or THEMES.vanilla
    local inX, inY, inW, inH = r.bx + pad * 1.2, r.themeY + pad * 1.2, r.bw - pad * 2.4, r.h - pad * 2.4
    self:drawRect(inX, inY, inW, inH, 1, theme.bg[1], theme.bg[2], theme.bg[3])
    local cols = { theme.road, theme.room, theme.tree }
    local sw = inW / 3
    for i, col in ipairs(cols) do
        self:drawRect(inX + (i - 1) * sw, inY + inH * 0.2, sw, inH * 0.6, 1, col[1], col[2], col[3])
    end
end

function M.Panel:drawControls(w)
    if BUTTON_TEX and ICON_TEX.camera and ICON_TEX.up then
        return self:drawControlsTex(w)
    end
    -- 絵が読めない時（mod の file が欠けた時だけ）: 四角の釦
    local r = controlRects(w)
    for _, y in ipairs({ r.upY, r.downY, r.rotY, r.zombY, r.themeY }) do
        self:drawRect(r.bx, y, r.bw, r.h, 0.8, 0.1, 0.1, 0.1)
        self:drawRectBorder(r.bx, y, r.bw, r.h, 0.9, 0.7, 0.7, 0.7)
    end
end

-- 横桿のつまみを x（この要素の中の位置）へ動かす。横桿が円の真下の中央に在るので、円の中心を止めたまま大きさを変える
-- （端を止めると、大きくするたびに横桿がずれ、つまみがマウスから離れる）。画面の外へ出た分は戻す
-- 倍率を刻み（scaleStep）の段へ丸め、上下限に収める。刻みは上下限の差を割り切る物だけなので、両端も段に乗る
function M.snapScale(v)
    local cfg = M.config
    local st = cfg.scaleStep
    local k = cfg.minUserScale + math.floor((v - cfg.minUserScale) / st + 0.5) * st
    return math.max(cfg.minUserScale, math.min(cfg.maxUserScale, math.floor(k * 100 + 0.5) / 100))
end

-- 大きさを 1 段変える（▲▼）。右上の角を止めたまま大きさを変え、今の倍率を字で出す
function M.Panel:stepScale(dir)
    local cfg = M.config
    cfg.userScale = M.snapScale(cfg.userScale + dir * cfg.scaleStep)
    local right = self:getX() + self:getWidth()
    M.resize(self)
    self:setX(math.max(0, right - self:getWidth()))
    M.toastRaw(string.format("%d%%", math.floor(cfg.userScale * 100 + 0.5)))
    M.optionsChanged()
end

-- 左ボタン: 操作の上なら操作、円の中なら掴んで動かす（原版 ISPanel.lua 49〜95 行と同じ形）。それ以外は通す
function M.Panel:onMouseDown(x, y)
    local w = self.mapSize or self:getWidth()
    local r = controlRects(w)
    -- 右の列の釦。押したら今の状態を円の上に少しの間だけ字で出す（利用者の指定 2026-09-29「切換的同時顯示目前切換的模式」）
    if x >= r.bx and x <= r.bx + r.bw then
        if y >= r.upY and y <= r.upY + r.h then
            self:stepScale(1)
            return true
        end
        if y >= r.downY and y <= r.downY + r.h then
            self:stepScale(-1)
            return true
        end
        if y >= r.themeY and y <= r.themeY + r.h then
            M.nextTheme()
            M.toast("Theme_" .. M.config.theme)
            M.optionsChanged()
            return true
        end
        if y >= r.zombY and y <= r.zombY + r.h then
            M.nextZombies()
            M.toast("Zombies_" .. M.config.zombies)
            M.optionsChanged()
            return true
        end
        if y >= r.rotY and y <= r.rotY + r.h then
            M.nextView()
            M.toast("View_" .. M.config.view)
            M.optionsChanged()
            return true
        end
        return false
    end
    local h = w / 2
    if (x - h) * (x - h) + (y - h) * (y - h) > h * h then return false end
    self.moving = true
    return true
end

function M.Panel:onMouseMove(dx, dy)
    if self.moving then
        self:setX(self.x + dx)
        self:setY(self.y + dy)
        self.userMoved = true
    end
end

function M.Panel:onMouseMoveOutside(dx, dy)
    self:onMouseMove(dx, dy)
end

function M.Panel:onMouseUp(x, y)
    self.moving = false
end

function M.Panel:onMouseUpOutside(x, y)
    self.moving = false
end

-- 滾輪で拡大・縮小。del が正なら縮小（遠くまで見る）。原版の地図と同じ向き（UIWorldMapV1.java 338 行・WorldMapRenderer.java 372 行）
function M.Panel:onMouseWheel(del)
    local cfg = M.config
    -- 今の視角の最大（斜めは小さい）で切ってから掛ける。切らないと、斜めで最大を超えた分だけ滾輪が効かない回が続く
    local maxR = cfg.view == "iso" and cfg.maxRadiusIso or cfg.maxRadius
    local r = math.min(cfg.radius, maxR) * (del > 0 and cfg.zoomStep or 1 / cfg.zoomStep)
    cfg.radius = math.floor(math.max(cfg.minRadius, math.min(maxR, r)) + 0.5)
    M.optionsChanged()
    return true
end

function M.Panel:new(x, y, size)
    return ISUIElement.new(self, x, y, size, size)
end

-- 測定の結果を返す（前回からの平均）。テスト橋の minimap 命令から呼ぶ
local function takeStats()
    local now = getTimestampMs()
    local f = math.max(stats.frames, 1)
    local line = string.format("minimap enabled=%s radius=%d frames=%d quads/frame=%.0f luaMs/frame=%.2f maxMs=%d window=%dms",
        tostring(M.config.enabled), M.config.radius, stats.frames, stats.quads / f, stats.luaMs / f, stats.maxMs, now - stats.since)
    if M.panel then
        -- 掴んで動かす試し用: 画面上の位置と大きさ
        line = line .. string.format(" panel=(%d,%d,%d) screen=%d scale=%.2f theme=%s view=%s zombies=%s", M.panel:getX(), M.panel:getY(),
            M.panel:getWidth(), getCore():getScreenWidth(), M.config.userScale, M.config.theme, M.config.view,
            M.config.zombies)
    end
    local p = getSpecificPlayer(0)
    if p then
        -- 向きの確かめ用: 体の角度・向こうとしている角度（度）と、向きのベクトル
        line = line .. string.format(" anim=%.1f dir=%.1f fwd=(%.2f,%.2f)", p:getAnimAngle(), p:getDirectionAngle(),
            p:getForwardDirectionX(), p:getForwardDirectionY())
    end
    stats = { frames = 0, quads = 0, luaMs = 0, maxMs = 0, since = now }
    return line
end

function M.command(name, value)
    if name == "off" then M.config.enabled = false; return "minimap off"
    elseif name == "on" then M.config.enabled = true; return "minimap on"
    elseif name == "radius" then M.config.radius = tonumber(value) or M.config.radius; cache = {}; runs = {}; return "minimap radius=" .. M.config.radius
    elseif name == "stats" then return takeStats()
    elseif name == "theme" then
        if THEMES[value or ""] then M.config.theme = value else M.nextTheme() end
        M.toast("Theme_" .. M.config.theme)
        return "minimap theme=" .. M.config.theme
    elseif name == "scale" then
        -- 試し用: 横桿と同じく大きさの倍率を替える（合成の入力が小地図に効かないため）
        local cfg = M.config
        cfg.userScale = math.max(cfg.minUserScale, math.min(cfg.maxUserScale, tonumber(value) or cfg.userScale))
        if M.panel then
            -- 桿と同じく右上の角を止める
            local right = M.panel:getX() + M.panel:getWidth()
            M.resize(M.panel)
            M.panel:setX(math.max(0, right - M.panel:getWidth()))
        end
        return "minimap scale=" .. cfg.userScale
    elseif name == "view" then
        if value == "camera" or value == "auto" or value == "north" or value == "iso" then M.config.view = value else M.nextView() end
        M.toast("View_" .. M.config.view)
        return "minimap view=" .. M.config.view
    elseif name == "zombies" then
        if value == "visible" or value == "all" or value == "off" then M.config.zombies = value else M.nextZombies() end
        M.toast("Zombies_" .. M.config.zombies)
        return "minimap zombies=" .. M.config.zombies
    elseif name == "camyaw" then
        -- 試し用: Java の橋が在るか・読めた鏡頭の向き（ラジアン。車の中は車体から見た首の角度）・車の中か・地図に使う角度（ラジアン）
        local y = Pz3dMinimapCamera and Pz3dMinimapCamera.yaw and Pz3dMinimapCamera.yaw()
        local vp = Pz3dMinimapCamera and Pz3dMinimapCamera.viewpointYaw and Pz3dMinimapCamera.viewpointYaw()
        local player = getSpecificPlayer(0)
        local seated = PZ3D and PZ3D.inVehicle and PZ3D.inVehicle()
        local used = player and M.cameraYaw(player)
        return string.format("camyaw link=%s yaw=%s viewpoint=%s seated=%s used=%s", tostring(Pz3dMinimapCamera ~= nil), tostring(y),
            tostring(vp), tostring(seated), tostring(used))
    elseif name == "materials" then
        local keys = {}
        for key, n in pairs(materials) do table.insert(keys, key .. "=" .. n) end
        table.sort(keys)
        return "materials " .. table.concat(keys, "; ")
    end
    return "minimap: unknown " .. tostring(name)
end

-- 初めの位置: 原版の速度ボタン（単機だけ。無ければ時計）のすぐ下で、右端に縦に並ぶ気分の絵（moodle）の左に、
-- margin だけ空けて付ける（利用者が単機で置いた位置 2026-09-29: 画面 1470x830 で (1166,132)）。
-- 時計 = 右上 y=10（UIManager.java 469〜471 行）。速度ボタン = 時計の下 10px、単機だけ見える（同 484〜495 行）。
-- 気分の絵 = 左端は画面の幅 - (10 + 絵の幅)（同 454 行）。OnGameStart の時点ではまだ並べ直されていない事があるので、
-- 位置は読まず、幅から計算する
local function sizeFor(cfg)
    return math.floor(cfg.baseSize * cfg.userScale * getCore():getScreenHeight() / cfg.baseScreenH + 0.5)
end

-- 円の直径を決め直す。要素の高さは円 + 操作の行
function M.resize(panel)
    local size = sizeFor(M.config)
    local f = uiScale()
    panel.mapSize = size
    -- 幅 = 円 + 右の列（桿と釦）、高さ = 円（下の釦の行は無くした。2026-09-30）
    panel:setWidth(size + (RING_TEX and RING_OUT * size or 0) + 4 + buttonSize())
    -- 小さな地図では右の列（桿と釦）が円より長くなる（controlRects）ので、その分も含める
    local r = controlRects(size)
    panel:setHeight(math.max(size, r.themeY + r.h))
    return size
end

local function defaultPos(cfg, size)
    local right = getCore():getScreenWidth() - 10
    local moodles = UIManager.getMoodleUI(0)
    if moodles then right = right - moodles:getWidth() end
    local top = 0
    local clock = UIManager.getClock()
    if clock and clock:isVisible() then top = clock:getY() + clock:getHeight() end
    local speed = UIManager.getSpeedControls()
    if speed and speed:isVisible() then top = math.max(top, speed:getY() + speed:getHeight()) end
    -- size は要素の幅（円 + 右の桿の列）
    return right - cfg.margin - size, top + cfg.margin
end

-- 大きさと位置を決め直す。利用者が動かした後は位置を変えず、画面の外へ出た分だけ戻す
local function place(panel)
    local cfg = M.config
    M.resize(panel)
    if panel.userMoved then
        local w, h = getCore():getScreenWidth(), getCore():getScreenHeight()
        panel:setX(math.max(0, math.min(panel:getX(), w - panel:getWidth())))
        panel:setY(math.max(0, math.min(panel:getY(), h - panel:getHeight())))
    else
        local x, y = defaultPos(cfg, panel:getWidth())
        panel:setX(x)
        panel:setY(y)
    end
end

-- 原版の UI は OnGameStart の後に並べ直される事があるので、最初の描画の時にもう一度置く
local baseRender = M.Panel.render
function M.Panel:render()
    if not self.placed then
        place(self)
        self.placed = true
    end
    baseRender(self)
end

-- 位置を初めの所へ戻す（設定の頁の釦）
function M.resetPosition()
    if M.panel then
        M.panel.userMoved = false
        place(M.panel)
    end
end

-- 設定の頁の項目。鍵 → 設定の値の間の読み書き。combo は順の表（VIEW_ORDER 等）の何番目か
-- ▲▼ の刻みの選べる値（倍率）
local SIZE_STEPS = { 0.01, 0.02, 0.05, 0.1, 0.25, 0.5 }

local function comboOf(order, value)
    for i, v in ipairs(order) do
        if v == value then return i end
    end
    return 1
end

function M.createOptions()
    if not (PZAPI and PZAPI.ModOptions) or modOptions then return end
    local cfg = M.config
    local o = PZAPI.ModOptions:create("aparosa_pz3dMinimap", "IGUI_pz3dMinimap_Options")
    o:addSlider("smoothing", "IGUI_pz3dMinimap_Smoothing", 0, 10, 1, 0, "IGUI_pz3dMinimap_SmoothingTip")
    local view = o:addComboBox("view", "IGUI_pz3dMinimap_OptView", "IGUI_pz3dMinimap_OptViewTip")
    -- combo の字は短い版（OptView_*・OptZombies_*）。提示の字（View_*）だと「Follows camera (PZ3D / V」のように combo の幅で
    -- 切れた（Windows の 14 言語の撮影、2026-09-30）。項目の名前が既に「視角」「殭屍」と言うので、括弧と「殭屍：」を外した物
    for _, k in ipairs(VIEW_ORDER) do view:addItem("IGUI_pz3dMinimap_OptView_" .. k, k == cfg.view) end
    local look = o:addComboBox("theme", "IGUI_pz3dMinimap_OptTheme")
    for _, k in ipairs(THEME_ORDER) do look:addItem("IGUI_pz3dMinimap_Theme_" .. k, k == cfg.theme) end
    local zomb = o:addComboBox("zombies", "IGUI_pz3dMinimap_OptZombies")
    for _, k in ipairs(ZOMBIE_ORDER) do zomb:addItem("IGUI_pz3dMinimap_OptZombies_" .. k, k == cfg.zombies) end
    -- 大きさの横桿は 1% 刻みで動かし、当てる時に ▲▼ の刻み（sizeStep）へ丸める（利用者「上下限也要符合多段變更的整數值」）
    o:addSlider("size", "IGUI_pz3dMinimap_OptSize", cfg.minUserScale * 100, cfg.maxUserScale * 100, 1, 100)
    -- ▲▼ 1 回の変わる量（利用者 2026-09-30「乾脆倍率也讓玩家可以從設定那邊自訂吧」）。50〜200% の両端が段に乗る物だけ
    -- （下限 50% と差 150% の両方を割り切る 1・2・5・10・25・50%。20% だと 190% の次が 200% に届かない。利用者「再多幾段吧」）。
    -- 字に % を入れない（原版の Translator が書式として読む）
    local step = o:addComboBox("sizeStep", "IGUI_pz3dMinimap_OptSizeStep")
    for _, v in ipairs(SIZE_STEPS) do step:addItem("IGUI_pz3dMinimap_Step" .. math.floor(v * 100 + 0.5), v == cfg.scaleStep) end
    o:addSlider("zoom", "IGUI_pz3dMinimap_OptZoom", cfg.minRadius, cfg.maxRadius, 1, cfg.radius)
    o:addSlider("opacity", "IGUI_pz3dMinimap_OptOpacity", 30, 100, 5, 100)
    o:addTickBox("seenOnly", "IGUI_pz3dMinimap_OptSeenOnly", false, "IGUI_pz3dMinimap_OptSeenOnlyTip")
    o:addTickBox("alwaysControls", "IGUI_pz3dMinimap_OptAlwaysControls", false)
    o:addTickBox("toast", "IGUI_pz3dMinimap_OptToast", true)
    o:addButton("resetPos", "IGUI_pz3dMinimap_OptResetPos", nil, function() M.resetPosition() end)
    -- 設定の頁で「適用」を押した時（MainOptions:apply が各 mod の options:apply を呼ぶ、MainOptions.lua 3760 行）
    function o:apply()
        M.applyOptions()
    end
    modOptions = o
end

-- 設定の頁の値 → 小地図の設定
function M.applyOptions()
    if not modOptions then return end
    local cfg = M.config
    local function v(id) local op = modOptions:getOption(id); return op and op:getValue() end
    cfg.smoothing = tonumber(v("smoothing")) or 0
    cfg.view = VIEW_ORDER[tonumber(v("view")) or 1] or cfg.view
    cfg.theme = THEME_ORDER[tonumber(v("theme")) or 1] or cfg.theme
    cfg.zombies = ZOMBIE_ORDER[tonumber(v("zombies")) or 1] or cfg.zombies
    cfg.scaleStep = SIZE_STEPS[tonumber(v("sizeStep")) or 4] or 0.1
    -- 大きさは刻みへ丸める（前の版の縦の桿で保存した 186% 等の半端な値も）
    cfg.userScale = M.snapScale((tonumber(v("size")) or 100) / 100)
    cfg.radius = math.max(cfg.minRadius, math.min(cfg.maxRadius, tonumber(v("zoom")) or cfg.radius))
    cfg.opacity = (tonumber(v("opacity")) or 100) / 100
    local seen = v("seenOnly") == true
    if seen ~= cfg.seenOnly then M.clearCache() end
    cfg.seenOnly = seen
    cfg.alwaysControls = v("alwaysControls") == true
    cfg.toast = v("toast") ~= false
    if M.panel then
        -- 大きさが変わっても右上の角を止める（大きさの桿と同じ）
        local right = M.panel:getX() + M.panel:getWidth()
        M.resize(M.panel)
        M.panel:setX(math.max(0, right - M.panel:getWidth()))
    end
end

-- 小地図の設定 → 設定の頁の値（ゲームの中の釦・桿・滾輪で変えた時）。保存は 1 秒まとめてから（滾輪の度に file を書かない）
function M.optionsChanged()
    if not modOptions then return end
    local cfg = M.config
    local function set(id, value) local op = modOptions:getOption(id); if op then op:setValue(value) end end
    set("view", comboOf(VIEW_ORDER, cfg.view))
    set("theme", comboOf(THEME_ORDER, cfg.theme))
    set("zombies", comboOf(ZOMBIE_ORDER, cfg.zombies))
    set("size", math.floor(cfg.userScale * 100 + 0.5))
    set("sizeStep", comboOf(SIZE_STEPS, cfg.scaleStep))
    set("zoom", cfg.radius)
    M.saveAt = getTimestampMs() + 1000
end

function M.saveIfDue()
    if M.saveAt and getTimestampMs() >= M.saveAt then
        M.saveAt = nil
        PZAPI.ModOptions:save()
    end
end

-- ModOptions.ini は設定の頁を開いた時にしか読まれない（MainOptions.lua 2796 行）ので、ゲームの始めに 1 度自分で読んで当てる
function M.loadOptions()
    if not modOptions then return end
    PZAPI.ModOptions:load()
    M.applyOptions()
end

M.createOptions()

local function create()
    if M.panel then return end
    M.loadOptions()
    M.panel = M.Panel:new(0, 0, sizeFor(M.config))
    M.resize(M.panel)
    M.panel:initialise()
    M.panel:addToUIManager()
    stats.since = getTimestampMs()
end

-- 画面の大きさが変わった時: 大きさを合わせ、動かしていなければ初めの位置へ置き直す
Events.OnResolutionChange.Add(function()
    if M.panel then place(M.panel) end
end)

Events.OnGameStart.Add(create)
