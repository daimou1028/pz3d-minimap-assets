-- 円形で、人物の向きに合わせて回る小地図（試作。重さを測るための物）
-- 原版の地図（UIWorldMap）は Lua から回せないので、周りのマスを読んで自前で描く（docs/vanilla-reference-ja.md）。
-- 描き方: 世界の 1 行ごとに同じ色のマスをまとめ、回した四角形 1 つとして 4 隅指定で描く。円は setStencilCircle で切る。
-- client に置く理由: ISUIElement が client の file で、require はしない（読込順の落とし穴に当たらない）。

aparosa_pz3dMinimap = aparosa_pz3dMinimap or {}
local M = aparosa_pz3dMinimap

M.config = {
    enabled = true,
    radius = 40,     -- 描くマスの半径。読み込まれている範囲は約 52 マス（13 チャンク x 8 / 2）
    -- 画面上の直径。基準の高さ 830px の時に 240px で、画面の高さに比例して大きくする（利用者の指定 2026-09-29。
    -- 830 は利用者が位置を決めた時の画面 1470x830）
    baseSize = 240,
    baseScreenH = 830,
    -- 利用者が横桿で変える倍率の幅（利用者の指定 2026-09-29: 大きくし過ぎ・小さくし過ぎを防ぐ）
    userScale = 1.0,
    minUserScale = 0.5,
    maxUserScale = 2.0,
    -- 操作の大きさ（px、基準の 830px の時）。
    -- 大きさの桿は縦にして円の右上に置く（利用者の指定 2026-09-29「改成垂直拉桿，放在右上角，大小變更起點是右上角」）
    ctrlH = 24,      -- 円の下の釦の行の高さ・縦の桿の列の幅
    sliderW = 110,   -- 縦の桿の長さ
    knobW = 10,      -- つまみの厚さ
    borderPx = 3,    -- 円の黒い縁の太さ（基準の 830px の時。画面の高さに比例）
    margin = 22,     -- 速度ボタン（無ければ時計）の下・気分の絵の左との間（px）。利用者が置いた位置から測った値
    refreshRows = 4, -- 1 フレームに色を読み直す行の数
    -- 滾輪の拡大・縮小の幅（利用者の決定 2026-09-29: 5〜55）。最大は読み込まれている範囲に収める。
    -- 単機で撮って、半径 60 で縁が黒くなり始め、70 で四隅が黒かった（読み込みは人物の周り約 ±60 の正方形）。
    -- 重さは Lua で半径 50 が 13ms、60 が 18ms/フレーム（Mac、-debug、2026-09-29）
    minRadius = 5,
    -- 最大は読み込まれている所（人物の周り約 ±58）に収め、縁に読まれていない黒い所が出ないようにする
    -- （利用者「範圍加到最大會出現一點點黑匡」2026-09-29。55 では斜めの時と、人物がチャンクの端に居る時に縁が黒くなった）。
    -- 斜めは縦に √2 倍遠くまで要るので 40（40 x 1.414 = 57）
    maxRadius = 50,
    maxRadiusIso = 40,
    zoomStep = 1.2,  -- 1 刻みの倍率
    -- 地図の見た目（材質）。円の右下の釦で順に替える（利用者の指定 2026-09-29「地圖材質切換」「預設應該用跟原本地圖相同材質」）
    theme = "vanilla",
    btnW = 22,       -- 下の釦の幅（基準の 830px の時）
    -- 視角（左下の 1 つの釦で順に替える。利用者の決定 2026-09-29: 回し方と斜めの釦を 1 つにまとめる）:
    --   "camera" = PZ3D の鏡頭の向きを上にして回す（既定。利用者「預設改為跟著鏡頭，可以切換為跟著人物」）。
    --              PZ3D は鏡頭の向き（LookState.yaw）を Lua へ出していない（0.3.0 の Main の public は 0.2.2 と同じ）。
    --              ただし一人称では毎フレーム人物の向きを鏡頭の向きに合わせる（NativeLocomotion.face が
    --              setTargetAndCurrentDirection(cos yaw, sin yaw) を呼ぶ。cameraFacing は FIRST_PERSON で常に真）。
    --              三人称では人物が鏡頭に合わせて回らない（狙う時だけ）。利用者の試し（Windows、2026-09-29）で
    --              人物の向きでは鏡頭に付いて来なかったので、PZ3D の鏡頭の向きを同梱の Java で直に読む（M.cameraYaw）。PZ3D が無い時は auto と同じ
    --   "auto"  = 真上から、人物の向き（体の回る角度 getAnimAngleRadians、滑らか）を上にして回す
    --   "north" = 真上から、北を上に止め、人物の印だけ回す（「視角固定或自動的切換」）
    --   "iso"   = 原版の地図の Isometric と同じ斜め（45 度回して縦を半分に潰す。WorldMapRenderer.java 197 行）。
    --             向きは遊戲の画面と同じ（北が右上）に止め、人物の印が向きを指す（「跟原版一樣的斜45度角」）
    view = "camera",
    -- 殭屍の点: "visible" = 人物に見えている殭屍だけ / "all" = 範囲の全部 / "off"。既定は visible（利用者の決定 2026-09-29）。
    -- 見えているかは、ゲームが殭屍を描くかを決める同じマスの見え方（IsoGridSquare.isCanSee、9219 行）で判じる
    zombies = "visible",
    -- マウスが小地図から離れた後、操作を残す時間（ms）。値の根拠は無い。円から桿へ移る間に消えない程度として置いた
    controlsLingerMs = 1000,
}

local ZOMBIE_ORDER = { "visible", "all", "off" }
local VIEW_ORDER = { "camera", "auto", "north", "iso" }

-- PZ3D の鏡頭の向き（世界の角度、ラジアン）。PZ3D の 3D でない時は nil。
-- 同梱の Java（java/src/aparosa/pz3dminimap/CameraLink.java）が ZombieBuddy の LuaClass で Lua へ Pz3dMinimapCamera を出し、
-- PZ3D の内部の LookState.get().yaw() を反射で読む。ZombieBuddy が無ければ Pz3dMinimapCamera は無く、人物の向きを使う。
-- 前の試作（マウスの横の動きを数える）は、PZ3D がマウスを掴む間 getMouseX が -10000 を返して使えなかった（2026-09-29、利用者の console）
function M.cameraYaw(player)
    local mode = PZ3D and PZ3D.cameraMode and PZ3D.cameraMode() or 0
    if mode == 0 then return nil end
    local yaw = Pz3dMinimapCamera and Pz3dMinimapCamera.yaw and Pz3dMinimapCamera.yaw()
    if yaw ~= nil and yaw ~= yaw then yaw = nil end  -- NaN（読めなかった）
    -- 読めない時: 一人称と狙う時は人物の向き = 鏡頭の向き（NativeLocomotion.face）、三人称は人物の向き
    local face = player:getDirectionAngleRadians()
    -- 車の中では PZ3D の yaw は車体から見た首の角度（0 = 車の正面、±110° まで。VehicleLook.HEAD_LIMIT、
    -- VehicleMotion の view が chassis の回転を掛けてから (-sin yaw, ·, cos yaw) を向く）。世界の角度ではないので、
    -- 車の向きを足す。乗っている間の人物の向きは車に付いて回る（Windows の実測 2026-09-30: 首を回しても dir は動かず、
    -- 車の getAngleY と dir ≈ angleY - 90° の関係）。足す向きの符号は chassis の軸の入れ替えから +（Windows で要確認）
    local seated = (PZ3D.inVehicle and PZ3D.inVehicle()) or player:getVehicle() ~= nil
    if seated then return face + (yaw or 0) end
    return yaw or face
end

-- 見た目の順（釦を押すと次へ）
local THEME_ORDER = { "vanilla", "flat" }

local function rgb(r, g, b) return { r / 255, g / 255, b / 255 } end

-- 見た目ごとの色（r, g, b）。bg = 円の地の色。色の無い種類は描かず地の色のまま見せる
local THEMES = {}
-- 原版の地図と同じ色（client/ISUI/Maps/ISMapDefinitions.lua の initDefaultStyleV1、163〜316 行、42.21.0）:
-- 紙の地 219,215,192 / 森 189,197,163 / 水 59,141,149 / 主な道 134,125,113 / 小道 171,158,143 / 建物（住宅）210,158,105。
-- 原版は草地・土を塗らず紙の地のまま見せ、壁は描かない。ここでは壁だけ建物の色を暗くして描く（部屋の形が分かるように）
THEMES.vanilla = {
    bg = rgb(219, 215, 192),
    none = rgb(200, 197, 176),  -- 読み込まれていない所。原版の未訪問（地 x 0.915）に近い色
    water = rgb(59, 141, 149),
    wall = rgb(140, 100, 62),
    room = rgb(210, 158, 105),
    tree = rgb(189, 197, 163),
    road = rgb(134, 125, 113),
    floor = rgb(171, 158, 143),
    paper = true,               -- 原版と同じく紙の絵を薄く重ねる（MapUtils.overlayPaper、352〜375 行: 白 alpha 32 + Paper.png）
}
-- 試作から使っていた色
THEMES.flat = {
    -- 地の色 = 読み込まれていない所に見える色（「none」は描かないので地が見える）。黒だと縁が黒い枠に見えたので灰にした
    bg       = { 0.22, 0.22, 0.22 },
    none     = { 0.22, 0.22, 0.22 },
    water    = { 0.20, 0.40, 0.75 },
    wall     = { 0.15, 0.15, 0.15 },
    room     = { 0.55, 0.50, 0.45 },
    tree     = { 0.18, 0.40, 0.18 },
    road     = { 0.35, 0.35, 0.37 },
    grass    = { 0.32, 0.52, 0.28 },
    ground   = { 0.50, 0.45, 0.33 },
    floor    = { 0.60, 0.58, 0.55 },
}
local PAPER_TEX = getTexture("media/textures/worldMap/Paper.png")

-- 色の記録: cache[y][x] = 種類の名前。z は人物の階だけ
local cache = {}
-- 行ごとの同じ色の続き（runs[y] = { x1, x2, 始め, 終わり+1, 種類, ... }）。行の中身か x1・x2 が変わった時だけ作り直す。
-- 毎フレーム範囲の全マス（半径 40 で約 6500）を見て続きを探していたのをやめた（2026-09-29、重さを減らすため）
local runs = {}
local cacheZ = nil
local refreshY = nil
local stats = { frames = 0, quads = 0, luaMs = 0, maxMs = 0, since = 0 }
local materials = {}

local function classify(sq)
    if not sq then return "none" end
    if sq:isWaterSquare() then return "water" end
    if sq:getWall(true) or sq:getWall(false) then return "wall" end
    if sq:getRoom() then return "room" end
    if sq:getTree() then return "tree" end
    local floor = sq:getFloor()
    if not floor then return "none" end
    local mat = floor:getProperties() and floor:getProperties():get("FloorMaterial")
    local name = floor:getSprite() and floor:getSprite():getName() or ""
    local key = tostring(mat) .. " " .. (string.match(name, "^(.-)_%d+$") or name)
    materials[key] = (materials[key] or 0) + 1
    if string.find(name, "street", 1, true) then return "road" end
    if mat == "Grass" then return "grass" end
    if mat == "Gravel" or mat == "Sand" or mat == "Dirt" then return "ground" end
    if string.find(name, "blends_natural", 1, true) then return "grass" end
    return "floor"
end

-- 行の x1〜x2 を読む。all が偽なら、まだ読んでいないマスだけを読む。
-- 前は行の端が欠けると行ごと読み直しており、人物が 1 マス動くと範囲の全マス（半径 40 で約 6500）を 1 フレームで読んで
-- 止まった（2026-09-29、利用者「好卡頓」。行の端 x1・x2 は動くたびに変わるため、すべての行が欠けて見えた）
local function readRow(cell, y, x1, x2, z, all)
    local row = cache[y]
    if not row then row = {}; cache[y] = row end
    for x = x1, x2 do
        if all or row[x] == nil then
            local kind = classify(cell:getGridSquare(x, y, z))
            if row[x] ~= kind then
                row[x] = kind
                runs[y] = nil
            end
        end
    end
end

-- 人物が前に掃除した所から半径より遠くへ動いたら、範囲の外のマスを捨てる（記録が際限なく増えないように）
local pruneX, pruneY = nil, nil
local function prune(px, py, r)
    if pruneX and math.abs(px - pruneX) <= r and math.abs(py - pruneY) <= r then return end
    pruneX, pruneY = px, py
    local keep = {}
    for y = py - r * 2, py + r * 2 do
        local row = cache[y]
        if row then
            local nrow = {}
            for x = px - r * 2, px + r * 2 do nrow[x] = row[x] end
            keep[y] = nrow
        end
    end
    cache = keep
    runs = {}
end

local CIRCLE_TEX = getTexture("media/ui/circle.png")

M.Panel = ISUIElement:derive("aparosa_pz3dMinimapPanel")

function M.Panel:render()
    local cfg = M.config
    if not cfg.enabled then return end
    local player = getSpecificPlayer(0)
    if not player then return end
    local t0 = getTimestampMs()
    local cell = getCell()
    local px, py = player:getX(), player:getY()
    local pz = math.floor(player:getZ())
    local r = math.min(cfg.radius, cfg.view == "iso" and cfg.maxRadiusIso or cfg.maxRadius)
    -- 斜めの時は縦を半分に潰すので、同じ円を埋めるには縦に遠くまで要る。表示を √2 倍に寄せ、読む範囲を √2 倍に広げる
    -- （読む範囲は読み込まれている所に収める）
    local iso = cfg.view == "iso"
    local isoK = iso and 1.4142 or 1
    local rr0 = iso and math.min(math.ceil(r * 1.4142), 58) or r
    local x1, x2 = math.floor(px) - rr0, math.floor(px) + rr0
    local y1, y2 = math.floor(py) - rr0, math.floor(py) + rr0
    if cacheZ ~= pz then cache = {}; runs = {}; cacheZ = pz end

    -- 無い行は読み、残りは数行ずつ順に読み直す（壁を建てた等の変化を拾う）
    prune(math.floor(px), math.floor(py), r)
    local theme = THEMES[cfg.theme] or THEMES.vanilla
    for y = y1, y2 do
        local row = cache[y]
        if not row or row[x1] == nil or row[x2] == nil then
            readRow(cell, y, x1, x2, pz, false)
        end
    end
    if not refreshY or refreshY < y1 or refreshY > y2 then refreshY = y1 end
    for _ = 1, cfg.refreshRows do
        readRow(cell, refreshY, x1, x2, pz, true)
        refreshY = refreshY + 1
        if refreshY > y2 then refreshY = y1 end
    end

    -- 向き: 人物が向いている方向を画面の上にする。θ = -pi/2 - 向き
    -- camera の時は、PZ3D の 3D の間は鏡頭の向きを数える（M.cameraYaw）。それ以外は体の角度（滑らか）
    local camYaw = cfg.view == "camera" and M.cameraYaw(player) or nil
    local a = camYaw or player:getAnimAngleRadians()
    -- 北を上に止める時は回さない（th = 0）。
    -- 斜めの時は原版の地図の Isometric と同じく、先に 45 度回してから縦を潰す（rotateXYZ(60°, 0, 45°)、WorldMapRenderer.java 197 行）。
    -- 回さずに潰すだけだと、マスが横長の四角になり比例がおかしかった（利用者「比例很怪」2026-09-29）。
    -- 45 度回すとマスが幅:高さ 2:1 の菱形になり、ゲームの画面と同じ向き（世界の x+ が右下、y+ が左下）になる。
    -- 画面に合わせるため、斜めの時は人物の向きでは回さず、人物の印の三角が向きを指す
    local th
    if iso then
        th = math.pi / 4
    elseif cfg.view == "north" then
        th = 0
    else
        th = -math.pi / 2 - a
    end
    local c, s = math.cos(th), math.sin(th)
    local w = self.mapSize or self:getWidth()  -- 円の直径。要素はこれに右の桿の列と下の釦の行を足した大きさ
    local cx, cy = w / 2, w / 2
    local k = w / (2 * r) * isoK
    -- 4 隅指定の DrawTexture は自分の位置を足さない（UIElement.java 304〜317 行）ので、画面の絶対座標で渡す
    local ax, ay = self:getAbsoluteX() + cx, self:getAbsoluteY() + cy
    local kc, ks = k * c, k * s
    -- 画面の縦の成分だけに掛ける倍率（斜めの時 0.5 = cos 60 度）
    local sqz = iso and 0.5 or 1
    local kcY, ksY = kc * sqz, ks * sqz

    -- 黒い縁: 地図より少し大きい黒い円を先に描き、円の外へ縁として見せる（利用者の指定 2026-09-29「如同封面一樣加一圈黑色框線」）。
    -- 円の絵は原版が setStencilCircle の型に使う物（media/ui/circle.png、白の塗りつぶし、UIElement.java 1936 行）を黒で塗る
    local border = math.max(2, math.floor(cfg.borderPx * getCore():getScreenHeight() / cfg.baseScreenH + 0.5))
    if CIRCLE_TEX then
        self:drawTextureScaled(CIRCLE_TEX, -border, -border, w + border * 2, w + border * 2, 1, 0, 0, 0)
    end
    self:setStencilCircle(0, 0, w, w)
    local bg = theme.bg
    self:drawRect(0, 0, w, w, 1, bg[1], bg[2], bg[3])
    local jo = self.javaObject
    local quads = 0
    for y = y1, y2 do
        local rr = runs[y]
        if not rr or rr[1] ~= x1 or rr[2] ~= x2 then
            -- この行の同じ色の続きを作り直す（「none」は描かないので入れない）
            local row = cache[y]
            rr = { x1, x2 }
            local runStart, runKind = x1, row[x1]
            for x = x1 + 1, x2 + 1 do
                local kind = row[x]
                if x > x2 or kind ~= runKind then
                    if runKind ~= "none" then
                        rr[#rr + 1] = runStart
                        rr[#rr + 1] = x
                        rr[#rr + 1] = runKind
                    end
                    runStart, runKind = x, kind
                end
            end
            runs[y] = rr
        end
        -- 回した四角の 4 隅: 画面 = a + k * 回転(dx, dy)。関数を呼ばずに式を書き下す
        local dy0, dy1 = y - py, y + 1 - py
        local ay0x, ay0y, ay1x, ay1y = ax - dy0 * ks, ay + dy0 * kcY, ax - dy1 * ks, ay + dy1 * kcY
        for i = 3, #rr, 3 do
            local dx0, dx1 = rr[i] - px, rr[i + 1] - px
            local col = theme[rr[i + 2]]
            if col then
                local x0c, x0s, x1c, x1s = dx0 * kc, dx0 * ksY, dx1 * kc, dx1 * ksY
                jo:DrawTexture(nil,
                    ay0x + x0c, ay0y + x0s, ay0x + x1c, ay0y + x1s,
                    ay1x + x1c, ay1y + x1s, ay1x + x0c, ay1y + x0s,
                    col[1], col[2], col[3], 1)
                quads = quads + 1
            end
        end
    end
    if theme.paper and PAPER_TEX then
        -- 原版と同じく、紙の絵を白 alpha 32/255 で重ねる（ISMapDefinitions.lua 368〜372 行）
        self:drawTextureScaled(PAPER_TEX, 0, 0, w, w, 32 / 255, 1, 1, 1)
    end
    -- 殭屍の点（円の中だけ。型で切っている間に描く）
    if cfg.zombies ~= "off" then
        quads = quads + self:drawZombies(player, px, py, pz, rr0, ax, ay, kc, ks, kcY, ksY, k)
    end
    -- 人物の印: 向いている方向を指す三角（北を上に止めた時も向きが分かるように、画面の上の向きへ回して描く）
    local fa = a + th                     -- 画面の上での向き（auto の時は常に -pi/2 = 上）
    local fx, fy = math.cos(fa), math.sin(fa) * sqz
    local fl = math.sqrt(fx * fx + fy * fy); fx, fy = fx / fl, fy / fl
    local sz = math.max(6, w / 30)
    local tipX, tipY = ax + fx * sz, ay + fy * sz
    local backX, backY = ax - fx * sz * 0.4, ay - fy * sz * 0.4
    local sideX, sideY = -fy * sz * 0.6, fx * sz * 0.6
    jo:DrawTexture(nil, tipX, tipY, backX + sideX - fx * sz * 0.3, backY + sideY - fy * sz * 0.3, backX, backY,
        backX - sideX - fx * sz * 0.3, backY - sideY - fy * sz * 0.3, 1, 0.2, 0.2, 1)
    self:clearStencilRect()
    self:repaintStencilRect(0, 0, w, w)
    -- 操作（桿と釦）はマウスが小地図の上に在る間だけ出し、離れてから少しの間（controlsLingerMs）残す。
    -- 普段は円だけにする（工坊の利用者の要望 2026-09-30「怎麼把小地圖周圍的圖示全部隱藏，讓介面保持乾淨」）。
    -- 残すのは、円から右上の桿へマウスを移す途中で隙間を通っても消えないようにするため。
    -- PZ3D がマウスを掴む間は getMouseX が -10000 を返すので、3D の間は常に隠れる
    local now = getTimestampMs()
    if self:isMouseOver() or self.moving or self.sliding then self.controlsUntil = now + M.config.controlsLingerMs end
    if now < (self.controlsUntil or 0) then
        self:drawControls(w)
    end
    if M.toastText and getTimestampMs() < (M.toastUntil or 0) then
        local font = UIFont.Small
        local tw = getTextManager():MeasureStringX(font, M.toastText)
        local fh = getTextManager():getFontHeight(font)
        local tx, ty = w / 2, w * 0.12
        self:drawRect(tx - tw / 2 - 6, ty - 2, tw + 12, fh + 4, 0.7, 0, 0, 0)
        self:drawTextCentre(M.toastText, tx, ty, 1, 1, 1, 1, font)
    end

    stats.frames = stats.frames + 1
    stats.quads = stats.quads + quads
    local ms = getTimestampMs() - t0
    stats.luaMs = stats.luaMs + ms
    if ms > stats.maxMs then stats.maxMs = ms end
end

-- 殭屍を点で描く。範囲（読む半径 r）の中で、同じ階の物だけ
function M.Panel:drawZombies(player, px, py, pz, r, ax, ay, kc, ks, kcY, ksY, k)
    local list = getCell():getZombieList()
    if not list then return 0 end
    local jo = self.javaObject
    local onlyVisible = M.config.zombies == "visible"
    local r2 = r * r
    local dot = math.max(2, math.min(6, k * 0.9))
    local n = 0
    for i = 0, list:size() - 1 do
        local z = list:get(i)
        if z and not z:isDead() and math.floor(z:getZ()) == pz then
            local dx, dy = z:getX() - px, z:getY() - py
            if dx * dx + dy * dy <= r2 then
                local sq = z:getCurrentSquare()
                if not onlyVisible or (sq and sq:isCanSee(player:getPlayerNum())) then
                    local x = ax + dx * kc - dy * ks
                    local y = ay + dx * ksY + dy * kcY
                    jo:DrawTexture(nil, x - dot, y - dot, x + dot, y - dot, x + dot, y + dot, x - dot, y + dot,
                        0.85, 0.1, 0.1, 1)
                    n = n + 1
                end
            end
        end
    end
    return n
end

-- 操作の大きさの倍率。円と同じく画面の高さに比例させる（4K で小さくなり過ぎないように）
local function uiScale()
    return getCore():getScreenHeight() / M.config.baseScreenH
end

-- 円の下の操作: 大きさの横桿は円の真下の中央に、切替の釦は右に寄せる（利用者の指定 2026-09-29「橫桿改到圓形正下方」「右側區域放各種切換按鈕」）。
-- 右から 斜めの釦・見た目の釦。幅・高さ・つまみは uiScale 倍
local function controlRects(w)
    local cfg = M.config
    local f = uiScale()
    local bw, gap = cfg.btnW * f, 4 * f
    -- 下の行: 左に視角の釦。右から 見た目の釦・殭屍の釦（円の右端に揃える）
    local rotX = 0
    local themeX = w - bw
    local zombX = themeX - gap - bw
    -- 右上: 縦の大きさの桿（円の右の列の上から）。長さは円の直径を超えない
    local thick = (cfg.ctrlH - 4) * f
    local len = math.min(cfg.sliderW * f, w)
    return { sx = w + gap, sy = 0, sw = thick, len = len, k = cfg.knobW * f,
             y = w + 2 * f, h = (cfg.ctrlH - 4) * f,
             bw = bw, themeX = themeX, zombX = zombX, rotX = rotX }
end

-- 切り替えた時に、今の状態を円の上に少しの間（1.5 秒）字で出す。字は翻訳の表（IGUI_pz3dMinimap_<鍵>）から引く
function M.toast(key)
    M.toastText = getText("IGUI_pz3dMinimap_" .. key)
    M.toastUntil = getTimestampMs() + 1500
end

-- 視角を次へ替える（俯瞰・回る → 俯瞰・北が上 → 斜め）
function M.nextView()
    local cfg = M.config
    for i, name in ipairs(VIEW_ORDER) do
        if name == cfg.view then
            cfg.view = VIEW_ORDER[i % #VIEW_ORDER + 1]
            return
        end
    end
    cfg.view = VIEW_ORDER[1]
end

-- 殭屍の点の出し方を次へ替える
function M.nextZombies()
    local cfg = M.config
    for i, name in ipairs(ZOMBIE_ORDER) do
        if name == cfg.zombies then
            cfg.zombies = ZOMBIE_ORDER[i % #ZOMBIE_ORDER + 1]
            break
        end
    end
end

-- 見た目を次へ替える
function M.nextTheme()
    local cfg = M.config
    for i, name in ipairs(THEME_ORDER) do
        if name == cfg.theme then
            cfg.theme = THEME_ORDER[i % #THEME_ORDER + 1]
            break
        end
    end
end

function M.Panel:drawControls(w)
    local cfg = M.config
    local r = controlRects(w)
    -- 縦の桿: 溝と、今の倍率の位置のつまみ（上ほど大きい）
    local t = (cfg.userScale - cfg.minUserScale) / (cfg.maxUserScale - cfg.minUserScale)
    local th = math.max(3, r.sw / 4)
    self:drawRect(r.sx + (r.sw - th) / 2, r.sy, th, r.len, 0.8, 0.1, 0.1, 0.1)
    self:drawRectBorder(r.sx + (r.sw - th) / 2, r.sy, th, r.len, 0.8, 0.5, 0.5, 0.5)
    self:drawRect(r.sx, r.sy + (1 - t) * (r.len - r.k), r.sw, r.k, 0.95, 0.85, 0.85, 0.85)
    -- 見た目の釦: 今の見た目の見本（字を使わないので翻訳が要らない）
    local theme = THEMES[cfg.theme] or THEMES.vanilla
    self:drawRect(r.themeX, r.y, r.bw, r.h, 1, theme.bg[1], theme.bg[2], theme.bg[3])
    local cols = { theme.road, theme.room, theme.tree }
    local sw = (r.bw - 4) / 3
    for i, col in ipairs(cols) do
        self:drawRect(r.themeX + 2 + (i - 1) * sw, r.y + 3, sw, r.h - 6, 1, col[1], col[2], col[3])
    end
    self:drawRectBorder(r.themeX, r.y, r.bw, r.h, 0.9, 0.7, 0.7, 0.7)
    local jo = self.javaObject
    local axs, ays = self:getAbsoluteX(), self:getAbsoluteY()
    -- 殭屍の釦: off = 灰の点、visible = 赤の点 1 つ、all = 赤の点 3 つ
    self:drawRect(r.zombX, r.y, r.bw, r.h, 0.8, 0.1, 0.1, 0.1)
    local d = math.max(2, r.h * 0.14)
    local zx, zy = r.zombX + r.bw / 2, r.y + r.h / 2
    if cfg.zombies == "off" then
        self:drawRect(zx - d, zy - d, d * 2, d * 2, 1, 0.45, 0.45, 0.45)
    elseif cfg.zombies == "visible" then
        self:drawRect(zx - d, zy - d, d * 2, d * 2, 1, 0.9, 0.15, 0.15)
    else
        for _, o in ipairs({ { -1.6, 1 }, { 1.6, 1 }, { 0, -1.2 } }) do
            self:drawRect(zx + o[1] * d * 1.4 - d, zy + o[2] * d * 1.4 - d, d * 2, d * 2, 1, 0.9, 0.15, 0.15)
        end
    end
    self:drawRectBorder(r.zombX, r.y, r.bw, r.h, 0.9, 0.7, 0.7, 0.7)
    -- 視角の釦: camera = 鏡頭の絵（四角と三角のレンズ）、auto = 上向きの三角（人物の向きが上）、north = 「N」の字、iso = 潰れた菱形
    self:drawRect(r.rotX, r.y, r.bw, r.h, 0.8, 0.1, 0.1, 0.1)
    local rx, ry = r.rotX + r.bw / 2, r.y + r.h / 2
    if cfg.view == "camera" then
        local bw2, bh2 = r.bw * 0.34, r.h * 0.26
        self:drawRect(rx - bw2, ry - bh2, bw2 * 1.4, bh2 * 2, 1, 0.9, 0.9, 0.9)
        jo:DrawTexture(nil, axs + rx + bw2 * 0.4, ays + ry, axs + rx + bw2, ays + ry - bh2, axs + rx + bw2, ays + ry + bh2,
            axs + rx + bw2 * 0.4, ays + ry, 0.9, 0.9, 0.9, 1)
    elseif cfg.view == "north" then
        local fh = getTextManager():getFontHeight(UIFont.Small)
        self:drawTextCentre("N", rx, ry - fh / 2, 0.9, 0.9, 0.9, 1, UIFont.Small)
    elseif cfg.view == "iso" then
        local hw = r.bw * 0.34
        local hh = hw * 0.5
        jo:DrawTexture(nil, axs + rx, ays + ry - hh, axs + rx + hw, ays + ry, axs + rx, ays + ry + hh, axs + rx - hw, ays + ry,
            0.85, 0.85, 0.85, 1)
    else
        local hs = r.h * 0.32
        jo:DrawTexture(nil, axs + rx, ays + ry - hs, axs + rx + hs * 0.8, ays + ry + hs, axs + rx, ays + ry + hs * 0.4,
            axs + rx - hs * 0.8, ays + ry + hs, 1, 0.3, 0.3, 1)
    end
    self:drawRectBorder(r.rotX, r.y, r.bw, r.h, 0.9, 0.7, 0.7, 0.7)
end

-- 横桿のつまみを x（この要素の中の位置）へ動かす。横桿が円の真下の中央に在るので、円の中心を止めたまま大きさを変える
-- （端を止めると、大きくするたびに横桿がずれ、つまみがマウスから離れる）。画面の外へ出た分は戻す
function M.Panel:slideTo(y)
    local cfg = M.config
    local w = self.mapSize or self:getWidth()
    local r = controlRects(w)
    local t = 1 - math.max(0, math.min(1, (y - r.sy - r.k / 2) / (r.len - r.k)))
    cfg.userScale = cfg.minUserScale + t * (cfg.maxUserScale - cfg.minUserScale)
    -- 右上の角を止めたまま大きさを変える（桿が右上に在るので、つまみがマウスの下に残る）
    local right = self:getX() + self:getWidth()
    M.resize(self)
    self:setX(math.max(0, right - self:getWidth()))
end

-- 左ボタン: 操作の上なら操作、円の中なら掴んで動かす（原版 ISPanel.lua 49〜95 行と同じ形）。それ以外は通す
function M.Panel:onMouseDown(x, y)
    local w = self.mapSize or self:getWidth()
    local r = controlRects(w)
    -- 右上の縦の桿
    if x >= r.sx - 3 and x <= r.sx + r.sw + 3 and y >= r.sy and y <= r.sy + r.len then
        self.sliding = true
        self:slideTo(y)
        return true
    end
    -- 下の釦の行。押したら今の状態を円の上に少しの間だけ字で出す（利用者の指定 2026-09-29「切換的同時顯示目前切換的模式」）
    if y >= r.y and y <= r.y + r.h then
        if x >= r.themeX and x <= r.themeX + r.bw then
            M.nextTheme()
            M.toast("Theme_" .. M.config.theme)
            return true
        end
        if x >= r.zombX and x <= r.zombX + r.bw then
            M.nextZombies()
            M.toast("Zombies_" .. M.config.zombies)
            return true
        end
        if x >= r.rotX and x <= r.rotX + r.bw then
            M.nextView()
            M.toast("View_" .. M.config.view)
            return true
        end
        return false
    end
    local h = w / 2
    if (x - h) * (x - h) + (y - h) * (y - h) > h * h then return false end
    self.moving = true
    return true
end

function M.Panel:onMouseMove(dx, dy)
    if self.sliding then
        self:slideTo(self:getMouseY())
    elseif self.moving then
        self:setX(self.x + dx)
        self:setY(self.y + dy)
        self.userMoved = true
    end
end

function M.Panel:onMouseMoveOutside(dx, dy)
    self:onMouseMove(dx, dy)
end

function M.Panel:onMouseUp(x, y)
    self.moving = false
    self.sliding = false
end

function M.Panel:onMouseUpOutside(x, y)
    self.moving = false
    self.sliding = false
end

-- 滾輪で拡大・縮小。del が正なら縮小（遠くまで見る）。原版の地図と同じ向き（UIWorldMapV1.java 338 行・WorldMapRenderer.java 372 行）
function M.Panel:onMouseWheel(del)
    local cfg = M.config
    -- 今の視角の最大（斜めは小さい）で切ってから掛ける。切らないと、斜めで最大を超えた分だけ滾輪が効かない回が続く
    local maxR = cfg.view == "iso" and cfg.maxRadiusIso or cfg.maxRadius
    local r = math.min(cfg.radius, maxR) * (del > 0 and cfg.zoomStep or 1 / cfg.zoomStep)
    cfg.radius = math.floor(math.max(cfg.minRadius, math.min(maxR, r)) + 0.5)
    return true
end

function M.Panel:new(x, y, size)
    return ISUIElement.new(self, x, y, size, size)
end

-- 測定の結果を返す（前回からの平均）。テスト橋の minimap 命令から呼ぶ
local function takeStats()
    local now = getTimestampMs()
    local f = math.max(stats.frames, 1)
    local line = string.format("minimap enabled=%s radius=%d frames=%d quads/frame=%.0f luaMs/frame=%.2f maxMs=%d window=%dms",
        tostring(M.config.enabled), M.config.radius, stats.frames, stats.quads / f, stats.luaMs / f, stats.maxMs, now - stats.since)
    if M.panel then
        -- 掴んで動かす試し用: 画面上の位置と大きさ
        line = line .. string.format(" panel=(%d,%d,%d) screen=%d scale=%.2f theme=%s view=%s zombies=%s", M.panel:getX(), M.panel:getY(),
            M.panel:getWidth(), getCore():getScreenWidth(), M.config.userScale, M.config.theme, M.config.view,
            M.config.zombies)
    end
    local p = getSpecificPlayer(0)
    if p then
        -- 向きの確かめ用: 体の角度・向こうとしている角度（度）と、向きのベクトル
        line = line .. string.format(" anim=%.1f dir=%.1f fwd=(%.2f,%.2f)", p:getAnimAngle(), p:getDirectionAngle(),
            p:getForwardDirectionX(), p:getForwardDirectionY())
    end
    stats = { frames = 0, quads = 0, luaMs = 0, maxMs = 0, since = now }
    return line
end

function M.command(name, value)
    if name == "off" then M.config.enabled = false; return "minimap off"
    elseif name == "on" then M.config.enabled = true; return "minimap on"
    elseif name == "radius" then M.config.radius = tonumber(value) or M.config.radius; cache = {}; runs = {}; return "minimap radius=" .. M.config.radius
    elseif name == "stats" then return takeStats()
    elseif name == "theme" then
        if THEMES[value or ""] then M.config.theme = value else M.nextTheme() end
        M.toast("Theme_" .. M.config.theme)
        return "minimap theme=" .. M.config.theme
    elseif name == "scale" then
        -- 試し用: 横桿と同じく大きさの倍率を替える（合成の入力が小地図に効かないため）
        local cfg = M.config
        cfg.userScale = math.max(cfg.minUserScale, math.min(cfg.maxUserScale, tonumber(value) or cfg.userScale))
        if M.panel then
            -- 桿と同じく右上の角を止める
            local right = M.panel:getX() + M.panel:getWidth()
            M.resize(M.panel)
            M.panel:setX(math.max(0, right - M.panel:getWidth()))
        end
        return "minimap scale=" .. cfg.userScale
    elseif name == "view" then
        if value == "camera" or value == "auto" or value == "north" or value == "iso" then M.config.view = value else M.nextView() end
        M.toast("View_" .. M.config.view)
        return "minimap view=" .. M.config.view
    elseif name == "zombies" then
        if value == "visible" or value == "all" or value == "off" then M.config.zombies = value else M.nextZombies() end
        M.toast("Zombies_" .. M.config.zombies)
        return "minimap zombies=" .. M.config.zombies
    elseif name == "camyaw" then
        -- 試し用: Java の橋が在るか・読めた鏡頭の向き（ラジアン。車の中は車体から見た首の角度）・車の中か・地図に使う角度（ラジアン）
        local y = Pz3dMinimapCamera and Pz3dMinimapCamera.yaw and Pz3dMinimapCamera.yaw()
        local player = getSpecificPlayer(0)
        local seated = PZ3D and PZ3D.inVehicle and PZ3D.inVehicle()
        local used = player and M.cameraYaw(player)
        return string.format("camyaw link=%s yaw=%s seated=%s used=%s", tostring(Pz3dMinimapCamera ~= nil), tostring(y),
            tostring(seated), tostring(used))
    elseif name == "materials" then
        local keys = {}
        for key, n in pairs(materials) do table.insert(keys, key .. "=" .. n) end
        table.sort(keys)
        return "materials " .. table.concat(keys, "; ")
    end
    return "minimap: unknown " .. tostring(name)
end

-- 初めの位置: 原版の速度ボタン（単機だけ。無ければ時計）のすぐ下で、右端に縦に並ぶ気分の絵（moodle）の左に、
-- margin だけ空けて付ける（利用者が単機で置いた位置 2026-09-29: 画面 1470x830 で (1166,132)）。
-- 時計 = 右上 y=10（UIManager.java 469〜471 行）。速度ボタン = 時計の下 10px、単機だけ見える（同 484〜495 行）。
-- 気分の絵 = 左端は画面の幅 - (10 + 絵の幅)（同 454 行）。OnGameStart の時点ではまだ並べ直されていない事があるので、
-- 位置は読まず、幅から計算する
local function sizeFor(cfg)
    return math.floor(cfg.baseSize * cfg.userScale * getCore():getScreenHeight() / cfg.baseScreenH + 0.5)
end

-- 円の直径を決め直す。要素の高さは円 + 操作の行
function M.resize(panel)
    local size = sizeFor(M.config)
    local f = uiScale()
    panel.mapSize = size
    -- 幅 = 円 + 右の縦の桿の列、高さ = 円 + 下の釦の行
    panel:setWidth(size + 4 * f + M.config.ctrlH * f)
    panel:setHeight(size + M.config.ctrlH * f)
    return size
end

local function defaultPos(cfg, size)
    local right = getCore():getScreenWidth() - 10
    local moodles = UIManager.getMoodleUI(0)
    if moodles then right = right - moodles:getWidth() end
    local top = 0
    local clock = UIManager.getClock()
    if clock and clock:isVisible() then top = clock:getY() + clock:getHeight() end
    local speed = UIManager.getSpeedControls()
    if speed and speed:isVisible() then top = math.max(top, speed:getY() + speed:getHeight()) end
    -- size は要素の幅（円 + 右の桿の列）
    return right - cfg.margin - size, top + cfg.margin
end

-- 大きさと位置を決め直す。利用者が動かした後は位置を変えず、画面の外へ出た分だけ戻す
local function place(panel)
    local cfg = M.config
    M.resize(panel)
    if panel.userMoved then
        local w, h = getCore():getScreenWidth(), getCore():getScreenHeight()
        panel:setX(math.max(0, math.min(panel:getX(), w - panel:getWidth())))
        panel:setY(math.max(0, math.min(panel:getY(), h - panel:getHeight())))
    else
        local x, y = defaultPos(cfg, panel:getWidth())
        panel:setX(x)
        panel:setY(y)
    end
end

-- 原版の UI は OnGameStart の後に並べ直される事があるので、最初の描画の時にもう一度置く
local baseRender = M.Panel.render
function M.Panel:render()
    if not self.placed then
        place(self)
        self.placed = true
    end
    baseRender(self)
end

local function create()
    if M.panel then return end
    M.panel = M.Panel:new(0, 0, sizeFor(M.config))
    M.resize(M.panel)
    M.panel:initialise()
    M.panel:addToUIManager()
    stats.since = getTimestampMs()
end

-- 画面の大きさが変わった時: 大きさを合わせ、動かしていなければ初めの位置へ置き直す
Events.OnResolutionChange.Add(function()
    if M.panel then place(M.panel) end
end)

Events.OnGameStart.Add(create)
